root = './search/'
debug = True
verbose = True
version  = '0.0'
SLEEP = 0.02